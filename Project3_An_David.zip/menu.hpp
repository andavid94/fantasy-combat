/*
 ** Description: This program contains the function prototypes for the menu.cpp file
 */

#ifndef menu_hpp
#define menu_hpp
#include "Character.hpp"

void begin();
void battle(Character*, Character*);

#endif
